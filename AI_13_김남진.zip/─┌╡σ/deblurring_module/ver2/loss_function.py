import numpy as np
from keras import backend as K
from keras.models import Model
from keras.applications.vgg16 import VGG16
import tensorflow as tf

# loss function 
image_shape = (256, 256, 3)

def l1_loss(y_true, y_pred):
    return K.mean(K.abs(y_pred - y_true))
  
# 생성자의 출력값에 대해 직접적으로 계산된 판단 손실값(perceptual loss) -- for discriminator
def perceptual_loss(y_true, y_pred):
    vgg = VGG16(include_top=False, weights='imagenet', input_shape=image_shape)
    loss_model = Model(inputs=vgg.input, outputs=vgg.get_layer('block3_conv3').output)
    loss_model.trainable = False
    return tf.reduce_mean(K.square(loss_model(y_true) - loss_model(y_pred)))

def perceptual_loss_100(y_true, y_pred):
    return 100 * perceptual_loss(y_true, y_pred)

# 전체 모델의 출력값에 대해 수행되는 와서슈타인 손실값 -- 두 이미지 간 평균을 가져온다.   -- for generator
def wasserstein_loss(y_true, y_pred):
    return tf.reduce_mean(y_true*y_pred)

def gradient_penalty_loss(self, y_true, y_pred, averaged_samples):
    gradients = K.gradients(y_pred, averaged_samples)[0]
    gradients_sqr = K.square(gradients)
    gradients_sqr_sum = K.sum(gradients_sqr,
                              axis=np.arange(1, len(gradients_sqr.shape)))

    gradient_l2_norm = K.sqrt(gradients_sqr_sum)
    gradient_penalty = K.square(1 - gradient_l2_norm)

    return K.mean(gradient_penalty)