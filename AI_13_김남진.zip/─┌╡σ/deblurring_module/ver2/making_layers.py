import tensorflow as tf

from keras.layers import Conv2D, Activation, BatchNormalization, Add
from keras.layers.core import Dropout


def res_block(input, filters, kernel_size=(3,3), strides=(1,1), use_dropout=False):
    
    x = Conv2D(fileters=filters, kernel_size=kernel_size, strides=strides, padding='same')(input)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)

    if use_dropout:
        x = Dropout(0.5)(x)

    x = Conv2D(filters=filters, kernel_size=kernel_size, strides=strides, padding='same')(x)
    x = BatchNormalization()(x)
    
    merged = Add()([input, x])
    return merged